"""
Bot module for FarnPathBot.
"""
