"""
Utilities module for FarnPathBot.
"""
