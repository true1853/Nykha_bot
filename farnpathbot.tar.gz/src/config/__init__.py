"""
Configuration module for FarnPathBot.
"""