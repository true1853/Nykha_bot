"""
Database module for FarnPathBot.
"""
