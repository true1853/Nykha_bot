"""
FarnPathBot - Spiritual practice application.
"""
__version__ = "2.0.0"
__author__ = "FarnPathBot Team"
