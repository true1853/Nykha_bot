"""
Tests for FarnPathBot.
"""
